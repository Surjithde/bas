Drop SSH public keys here and sync:
- Read-only keys: /opt/mco/keys/mco-readonly/*.pub  -> mco_ro
- Support users:  /opt/mco/keys/mco-support/<username>.pub

Commands:
  sudo /opt/mco/bin/mco-ro-keys-sync
  sudo /opt/mco/bin/mco-add-support-user <username>

Apply to VMs:
  cd /opt/mco/ansible && ansible-playbook -i inventory.ini playbooks_minimal.yml
